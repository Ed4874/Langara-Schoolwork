//Program Name: MyInformation
//Author: Edward Lu
//Student Number: 100359822
//Date Written: September 11, 2020
//Course: CPSC 1150-W04
//Compiler: JDK 14
//Purpose: This program will display my name, student number, as well as the courses that I am taking this semester.

public class MyInformation
{
	public static void main(String[] args) {
		//Shows my information
		System.out.println("Name: \nEdward Lu");
		System.out.println("Student Number: \n100359822");
		System.out.println("Courses: \nCPSC 1050-W08 \nCPSC 1150-W04 \nENGL 1123-W31 \nHIST 1115-W01");
	}
}