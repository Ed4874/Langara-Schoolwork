public class Birthday extends Card {
    private int birthday;

    public Birthday(String recipeint, int birthday) {
        super(recipeint);
        this.birthday = birthday;
    }

    public String birthdayEnding() {
        String end = "";

        if(birthday == 11 || birthday == 12 || birthday == 13) {
            end = "th";
            return end;
        }

        int k = birthday%10;
        
        switch(k) {
            case 1:
                end = "st";
                break;
            case 2:
                end = "nd";
                break;
            case 3:
                end = "rd";
                break;
            default:
                end = "th";
                break;
        }

        return end;
    }

    public void greeting() {
        System.out.println("Dear " + getRecipient() + "\n\tHappy " + birthday + birthdayEnding() + " Birthday");
    }
}
