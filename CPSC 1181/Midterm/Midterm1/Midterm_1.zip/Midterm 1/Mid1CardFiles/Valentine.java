public class Valentine extends Card {
    private int kisses;

    public Valentine(String recipeint, int kisses) {
        super(recipeint);
        this.kisses = kisses;
    }

    public String kissCount() {
        int i = 0;
        String x = "";
        while(i < kisses) {
            x += "X";
            i++;
        }

        return x;
    } 

    public void greeting() {
        System.out.println("My " + getRecipient() + "\n\tLove and Kisses,\n" + kissCount());
    }
}
