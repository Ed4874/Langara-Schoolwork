/**Student Name: Edward Lu
 * Student Number: 100359822
 * Date Written: January 05, 2021
 * JDK Version: 14 (IntelliJ)
 * Purpose: This program will play the "Mystery Number" Game.
 **/

import javax.swing.*;

public class edwardLMysteryNumber {
    public static void main (String[] args) {
        String[] options = {"Beginner", "Intermediate", "Expert"};
        int x = JOptionPane.showOptionDialog(null, "Which difficulty would you like to play on?",
                "Mystery Number",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[2]);
        if (x < 0) {
            System.exit(0);
        }
        else {
            stepOne(x);
        }
    }
    public static void stepOne (int x){
        JOptionPane.showMessageDialog(null, "Please think of an integer.", "Step One",
                JOptionPane.PLAIN_MESSAGE);
        stepTwo(x);
    }
    public static void stepTwo (int x) {
        JOptionPane.showMessageDialog(null, "Add 25 to your number.", "Step Two",
                JOptionPane.PLAIN_MESSAGE);
        stepThree(x);
    }
    public static void stepThree (int x) {
        JOptionPane.showMessageDialog(null, "Divide your number by 4.", "Step Three",
                JOptionPane.PLAIN_MESSAGE);
        switch (x) {
            case 0:
                beginnerResult(x);
            case 1,2:
                stepFour(x);
        }
    }
    public static void stepFour (int x) {
        JOptionPane.showMessageDialog(null, "Subtract 2 from your number.", "Step Four",
                JOptionPane.PLAIN_MESSAGE);
        stepFive(x);
    }
    public static void stepFive (int x) {
        JOptionPane.showMessageDialog(null, "Multiply your number by 3.", "Step Five",
                JOptionPane.PLAIN_MESSAGE);
        switch (x) {
            case 1:
                intermediateResult(x);
            case 2:
                stepSix(x);
        }
    }
    public static void stepSix (int x) {
        JOptionPane.showMessageDialog(null, "Add 33 to your your number.", "Step Six",
                JOptionPane.PLAIN_MESSAGE);
        stepSeven(x);
    }
    public static void stepSeven (int x) {
        JOptionPane.showMessageDialog(null, "Subtract 17 from your number.", "Step Seven",
                JOptionPane.PLAIN_MESSAGE);
        expertResult(x);
    }
    public static void beginnerResult(int x) {
        String input = JOptionPane.showInputDialog(null, "Input Prompt:", "Beginner Mode", JOptionPane.QUESTION_MESSAGE);
        if (input == null) {
            System.exit(0);
        }
        int number = (int)((Double.parseDouble(input) * 4) - 25);
        numberGuess(number, x);
    }
    public static void intermediateResult(int x) {
        String input = JOptionPane.showInputDialog(null, "Input Prompt:", "Intermediate Mode", JOptionPane.QUESTION_MESSAGE);
        if (input == null) {
            System.exit(0);
        }
        int number = (int)((((Double.parseDouble(input) / 3) + 2) * 4) - 25);
        numberGuess(number, x);
    }
    public static void expertResult(int x) {
        String input = JOptionPane.showInputDialog(null, "Input Prompt:", "Expert Mode", JOptionPane.QUESTION_MESSAGE);
        if (input == null) {
            System.exit(0);
        }
        int number = (int)((((((Double.parseDouble(input) + 17) - 33) / 3) + 2) * 4) - 25);
        numberGuess(number, x);
    }
    public static void numberGuess (int finalNumber, int x) {
        JOptionPane.showMessageDialog(null, "I'm guessing your number is " + finalNumber + ".", "Result",
                JOptionPane.PLAIN_MESSAGE);
        restart(x);
    }
    public static void restart (int x) {
        String[] options = {"Yes", "No"};
        int y = JOptionPane.showOptionDialog(null, "Would you like to play again?",
                "Replay?",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[1]);
        if (y == 0) {
            stepOne(x);
        }
        else {
            System.exit(0);
        }
    }
}
